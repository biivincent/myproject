<?php
/* @var $this UserSettingsController */
/* @var $model UserSettings */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'user-settings-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'user_id'); ?>
		<?php echo $form->textField($model,'user_id',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'user_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'dateformat'); ?>
		<?php echo $form->textField($model,'dateformat',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'dateformat'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'displaydate'); ?>
		<?php echo $form->textField($model,'displaydate',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'displaydate'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'timezone'); ?>
		<?php echo $form->textField($model,'timezone',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'timezone'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'timeformat'); ?>
		<?php echo $form->textField($model,'timeformat',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'timeformat'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'name_format'); ?>
		<?php echo $form->textField($model,'name_format',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'name_format'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'language'); ?>
		<?php echo $form->textField($model,'language',array('size'=>60,'maxlength'=>120)); ?>
		<?php echo $form->error($model,'language'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->