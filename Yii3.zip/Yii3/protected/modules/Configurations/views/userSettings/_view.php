<?php
/* @var $this UserSettingsController */
/* @var $data UserSettings */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_id')); ?>:</b>
	<?php echo CHtml::encode($data->user_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('dateformat')); ?>:</b>
	<?php echo CHtml::encode($data->dateformat); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('displaydate')); ?>:</b>
	<?php echo CHtml::encode($data->displaydate); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('timezone')); ?>:</b>
	<?php echo CHtml::encode($data->timezone); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('timeformat')); ?>:</b>
	<?php echo CHtml::encode($data->timeformat); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name_format')); ?>:</b>
	<?php echo CHtml::encode($data->name_format); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('language')); ?>:</b>
	<?php echo CHtml::encode($data->language); ?>
	<br />

	*/ ?>

</div>