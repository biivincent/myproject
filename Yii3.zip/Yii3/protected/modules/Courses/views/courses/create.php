<?php
/* @var $this CoursesController */
/* @var $model Courses */

$this->breadcrumbs=array(
	'Courses'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Courses', 'url'=>array('index')),
	array('label'=>'Manage Courses', 'url'=>array('admin')),
);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
    <div class="cont_right formWrapper">

<h1><?php echo Yii::t('courses','Create Course');?></h1><br />

<?php echo $this->renderPartial('_form', array('model'=>$model,'model_1'=>$model_1)); ?>

 	</div>
    </td>
  </tr>
</table>