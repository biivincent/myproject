<?php
/* @var $this ElectiveGroupsController */
/* @var $model ElectiveGroups */

$this->breadcrumbs=array(
	'Elective Groups'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List ElectiveGroups', 'url'=>array('index')),
	array('label'=>'Manage ElectiveGroups', 'url'=>array('admin')),
);
?>

<h1>Create ElectiveGroups</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>