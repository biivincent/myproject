<?php

echo CHtml::ajaxLink('Test request',
	array('ajax/reqTest01'),array('update'=>'#req_res')
	);
	echo '<div id="req_res"...</div>';